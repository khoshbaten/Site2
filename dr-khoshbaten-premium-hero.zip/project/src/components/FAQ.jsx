import { useState } from 'react';
import { useScrollReveal } from '../hooks/useScrollReveal';

const FAQ = () => {
  const [titleRef, titleVisible] = useScrollReveal();
  const [faqsRef, faqsVisible] = useScrollReveal();
  const [openIndex, setOpenIndex] = useState(0);

  const faqs = [
    {
      question: 'آیا حتماً باید نوبت رزرو کنم؟',
      answer: 'بله، برای دریافت بهترین خدمات و جلوگیری از انتظار طولانی، پیشنهاد می‌کنیم حتماً از طریق تلفن یا آنلاین نوبت خود را رزرو کنید. تیم ما در اسرع وقت نوبت مناسب را برای شما هماهنگ خواهد کرد.',
    },
    {
      question: 'مدت زمان هر جلسه درمان چقدر است؟',
      answer: 'مدت زمان هر جلسه بسته به نوع درمان برنامه‌ریزی شده، معمولاً بین ۴۵ تا ۹۰ دقیقه متغیر است. در جلسه مشاوره اولیه، متخصص تمام جزئیات را برای شما توضیح خواهد داد.',
    },
    {
      question: 'آیا خدمات شما تحت پوشش بیمه است؟',
      answer: 'بله، اکثر خدمات کلینیک ما تحت پوشش بیمه‌های سلامت، تأمین اجتماعی و بیمه‌های تکمیلی قرار می‌گیرد. لطفاً قبل از مراجعه، از پوشش بیمه خود اطمینان حاصل کنید.',
    },
    {
      question: 'تعداد جلسات درمان چند جلسه است؟',
      answer: 'تعداد جلسات درمان کاملاً وابسته به نوع و شدت مشکل است. پس از ارزیابی اولیه، متخصص برنامه درمانی و تعداد جلسات مورد نیاز را برای شما مشخص خواهد کرد.',
    },
    {
      question: 'آیا برای کودکان و سالمندان هم خدمات ارائه می‌دهید؟',
      answer: 'بله، کلینیک ما خدمات تخصصی برای تمام گروه‌های سنی از کودکان تا سالمندان ارائه می‌دهد. برنامه درمانی متناسب با نیاز و ظرفیت هر گروه سنی طراحی می‌شود.',
    },
    {
      question: 'آیا پس از درمان تمرینات خانگی هم داریم؟',
      answer: 'قطعاً! بخش مهمی از درمان، تمرینات خانگی است که به شما آموزش داده می‌شود. این تمرینات به تسریع بهبودی و پیشگیری از عود مشکلات کمک می‌کنند.',
    },
    {
      question: 'آیا می‌توانم قبل از رزرو نوبت مشاوره بگیرم؟',
      answer: 'بله، شما می‌توانید با تماس تلفنی با شماره ۰۵۱۴۷۲۵۹۰۰۵ مشاوره اولیه دریافت کنید. تیم ما پاسخگوی سوالات شما و راهنمایی در مورد فرآیند درمان خواهد بود.',
    },
    {
      question: 'آخرین ساعت مراجعه چه زمانی است؟',
      answer: 'ساعات کاری کلینیک شنبه تا چهارشنبه از ساعت ۸ صبح تا ۸ شب و پنج‌شنبه‌ها از ۸ صبح تا ۲ بعدازظهر است. آخرین نوبت معمولاً یک ساعت پیش از پایان وقت پذیرش می‌شود.',
    },
  ];

  return (
    <section id="faq" className="py-24 bg-gradient-to-b from-white to-[#f0fdf4]">
      <div className="container mx-auto px-4 md:px-6">
        <div
          ref={titleRef}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block px-4 py-2 bg-[#dcfce7] text-[#16a34a] rounded-full text-sm font-semibold mb-4">
            سوالات متداول
          </span>
          <h2 className="section-title">پاسخ به سوالات شما</h2>
          <p className="section-subtitle max-w-2xl mx-auto">
            پاسخ به سوالات رایج درباره خدمات و فرآیند درمان در کلینیک ما
          </p>
        </div>

        <div
          ref={faqsRef}
          className={`max-w-3xl mx-auto transition-all duration-700 ${
            faqsVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className={`glass-card overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'shadow-xl' : 'hover:shadow-lg'
                }`}
              >
                <button
                  onClick={() => setOpenIndex(openIndex === index ? -1 : index)}
                  className="w-full flex items-center justify-between p-5 text-right focus:outline-none"
                >
                  <span className="text-lg font-semibold text-gray-800 pr-4">{faq.question}</span>
                  <div
                    className={`w-10 h-10 flex-shrink-0 rounded-full flex items-center justify-center transition-all duration-300 ${
                      openIndex === index
                        ? 'bg-[#00a86b] text-white rotate-180'
                        : 'bg-[#dcfce7] text-[#00a86b]'
                    }`}
                  >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </button>
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openIndex === index ? 'max-h-96' : 'max-h-0'
                  }`}
                >
                  <div className="px-5 pb-5 text-gray-600 leading-relaxed">
                    <div className="pt-2 pb-4 border-t border-gray-100">
                      {faq.answer}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-gray-600 mb-4">سوال دیگری دارید؟</p>
            <a href="#contact" className="btn-primary">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.939-5.247A9.93 9.93 0 013 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
              تماس با ما
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
