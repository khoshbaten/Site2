import { useScrollReveal } from '../hooks/useScrollReveal';

const Benefits = () => {
  const [titleRef, titleVisible] = useScrollReveal();
  const [benefitsRef, benefitsVisible] = useScrollReveal();

  const benefits = [
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
        </svg>
      ),
      title: 'تخصص و تجربه',
      description: 'بیش از ۱۵ سال تجربه در درمان انواع آسیب‌های اسکلتی عضلانی',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
        </svg>
      ),
      title: 'روش‌های علمی',
      description: 'استفاده از تکنیک‌های مدرن MBTIبسته بر تواه علمی',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.281-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.281.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      ),
      title: 'تیم مجرب',
      description: 'متخصصین با تحصیلات عالی و دوره‌های تخصصی بین‌المللی',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
        </svg>
      ),
      title: 'برنامه اختصاصی',
      description: 'طراحی برنامه درمانی متناسب با نیازها و شرایط هر بیمار',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      title: 'نوبت‌دهی سریع',
      description: 'امکان رزرو آنلاین و تلفنی با کمترین زمان انتظار',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      ),
      title: 'هزینه مناسب',
      description: 'خدمات باکیفیت با تعرفه‌های منصفانه و پوشش بیمه',
    },
  ];

  return (
    <section id="benefits" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#dcfce7] rounded-full blur-3xl opacity-50"></div>
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-[#fef3c7] rounded-full blur-3xl opacity-50"></div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div
          ref={titleRef}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block px-4 py-2 bg-[#fef3c7] text-[#b45309] rounded-full text-sm font-semibold mb-4">
            چرا کلینیک ما؟
          </span>
          <h2 className="section-title">مزایای انتخاب کلینیک ما</h2>
          <p className="section-subtitle max-w-2xl mx-auto">
            دلایلی که ما را به انتخاب اول بیماران تبدیل کرده است
          </p>
        </div>

        <div
          ref={benefitsRef}
          className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 transition-all duration-700 ${
            benefitsVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="group text-center p-6 rounded-2xl hover:bg-[#f0fdf4] transition-all duration-300"
            >
              <div className="w-20 h-20 mx-auto bg-gradient-to-br from-[#f0fdf4] to-[#dcfce7] rounded-2xl flex items-center justify-center text-[#00a86b] mb-6 group-hover:bg-gradient-jade group-hover:text-white group-hover:scale-110 transition-all duration-300 shadow-lg group-hover:shadow-[#00a86b]/20">
                {benefit.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{benefit.title}</h3>
              <p className="text-gray-600 leading-relaxed">{benefit.description}</p>
            </div>
          ))}
        </div>

        <div
          className={`mt-16 text-center transition-all duration-700 delay-300 ${
            benefitsVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="inline-flex flex-wrap justify-center gap-6 p-8 bg-gradient-to-r from-[#f0fdf4] to-[#dcfce7] rounded-3xl">
            <div className="text-center px-6">
              <div className="text-4xl font-black text-[#00a86b] mb-1">۱۵+</div>
              <div className="text-gray-600 text-sm">سال تجربه</div>
            </div>
            <div className="w-px bg-[#bbf7d0] hidden sm:block"></div>
            <div className="text-center px-6">
              <div className="text-4xl font-black text-[#b45309] mb-1">۵۰۰۰+</div>
              <div className="text-gray-600 text-sm">بیمار موفق</div>
            </div>
            <div className="w-px bg-[#bbf7d0] hidden sm:block"></div>
            <div className="text-center px-6">
              <div className="text-4xl font-black text-[#00a86b] mb-1">۹۸%</div>
              <div className="text-gray-600 text-sm">رضایت بیماران</div>
            </div>
            <div className="w-px bg-[#bbf7d0] hidden sm:block"></div>
            <div className="text-center px-6">
              <div className="text-4xl font-black text-[#b45309] mb-1">۱۲+</div>
              <div className="text-gray-600 text-sm">خدمات تخصصی</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Benefits;
