import { useScrollReveal } from '../hooks/useScrollReveal';

const TargetAudiences = () => {
  const [titleRef, titleVisible] = useScrollReveal();
  const [cardsRef, cardsVisible] = useScrollReveal();

  const audiences = [
    {
      icon: (
        <svg className="w-14 h-14" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      ),
      title: 'ورزشکاران آسیب‌دیده',
      description: 'بازگشت سریع و ایمن به ورزش',
      features: ['توانبخشی پس از آسیب', 'بهبود عملکرد ورزشی', 'پیشگیری از آسیب مجدد'],
      image: 'https://images.pexels.com/photos/4162492/pexels-photo-4162492.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      title: 'بیماران و سالمندان',
      description: 'مراقبت ویژه برای بهبودی کامل',
      features: ['توانبخشی پس از جراحی', 'مدیریت دردهای مزمن', 'بهبود کیفیت زندگی'],
      image: 'https://images.pexels.com/photos/545229/pexels-photo-545229.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      icon: (
        <svg className="w-14 h-14" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
        </svg>
      ),
      title: 'ناهنجاری‌های اسکلتی',
      description: 'اصلاح فرم بدن و posture',
      features: ['اصلاح کایفوز و لوردوز', 'درمان اسکولیوز', 'اصلاح شانه برجسته'],
      image: 'https://images.pexels.com/photos/4224143/pexels-photo-4224143.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      icon: (
        <svg className="w-14 h-14" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      title: 'درد‌های مفصلی',
      description: 'تسکین و درمان قطعی دردها',
      features: ['درمان آرتروز', 'رفع کمردرد و گردن‌درد', 'درمان دردهای زانو'],
      image: 'https://images.pexels.com/photos/4162498/pexels-photo-4162498.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
  ];

  return (
    <section id="audiences" className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div
          ref={titleRef}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block px-4 py-2 bg-[#fef3c7] text-[#b45309] rounded-full text-sm font-semibold mb-4">
            گروه‌های هدف
          </span>
          <h2 className="section-title">خدمات ما برای چه کسانی است؟</h2>
          <p className="section-subtitle max-w-2xl mx-auto">
            کلینیک ما آماده ارائه خدمات تخصصی به تمامی گروه‌های سنی و نیازهای متنوع است
          </p>
        </div>

        <div
          ref={cardsRef}
          className={`grid grid-cols-1 md:grid-cols-2 gap-8 transition-all duration-700 ${
            cardsVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {audiences.map((audience, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-3xl bg-gradient-to-br from-gray-50 to-white shadow-lg hover:shadow-2xl transition-all duration-500"
            >
              <div className="flex flex-col md:flex-row">
                <div className="md:w-2/5 relative overflow-hidden">
                  <img
                    src={audience.image}
                    alt={audience.title}
                    className="w-full h-48 md:h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#007047]/50 to-transparent md:bg-gradient-to-r"></div>
                </div>
                <div className="md:w-3/5 p-6 md:p-8">
                  <div className="w-14 h-14 bg-gradient-jade rounded-xl flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform duration-300">
                    {audience.icon}
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{audience.title}</h3>
                  <p className="text-gray-600 mb-4">{audience.description}</p>
                  <ul className="space-y-2">
                    {audience.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                        <svg className="w-5 h-5 text-[#00a86b] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TargetAudiences;
