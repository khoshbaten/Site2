import { useScrollReveal } from '../hooks/useScrollReveal';

const Contact = () => {
  const [contentRef, contentVisible] = useScrollReveal();
  const [formRef, formVisible] = useScrollReveal();

  const contactInfo = [
    {
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      ),
      title: 'آدرس',
      content: 'خراسان رضوی، قوچان، خیابان نیکویی، مجتمع پزشکی پارسه، واحد ۳',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
        </svg>
      ),
      title: 'تلفن',
      content: '۰۵۱۴۷۲۵۹۰۰۵',
      link: 'tel:05147259005',
    },
    {
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      title: 'ساعات کاری',
      content: 'شنبه تا چهارشنبه: ۸ صبح تا ۸ شب\nپنج‌شنبه: ۸ صبح تا ۲ بعدازظهر',
    },
  ];

  return (
    <section id="contact" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-[#f0fdf4] to-transparent"></div>
      <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-[#dcfce7] rounded-full blur-3xl opacity-40"></div>
      <div className="absolute -top-20 -left-20 w-96 h-96 bg-[#fef3c7] rounded-full blur-3xl opacity-40"></div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 bg-[#dcfce7] text-[#16a34a] rounded-full text-sm font-semibold mb-4">
            تماس با ما
          </span>
          <h2 className="section-title">با ما در ارتباط باشید</h2>
          <p className="section-subtitle max-w-2xl mx-auto">
            برای رزرو نوبت یا مشاوره رایگان با ما تماس بگیرید
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div
            ref={contentRef}
            className={`space-y-6 transition-all duration-700 ${
              contentVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'
            }`}
          >
            {contactInfo.map((item, index) => (
              <div
                key={index}
                className="group flex items-start gap-4 p-5 glass-card hover:shadow-xl transition-all duration-300"
              >
                <div className="w-12 h-12 flex-shrink-0 bg-gradient-jade rounded-xl flex items-center justify-center text-white group-hover:scale-110 transition-transform duration-300">
                  {item.icon}
                </div>
                <div>
                  <h3 className="font-bold text-gray-800 mb-1">{item.title}</h3>
                  {item.link ? (
                    <a
                      href={item.link}
                      className="text-[#00a86b] hover:text-[#008f5b] transition-colors"
                      dir="ltr"
                    >
                      {item.content}
                    </a>
                  ) : (
                    <p className="text-gray-600 whitespace-pre-line">{item.content}</p>
                  )}
                </div>
              </div>
            ))}

            <div className="flex flex-wrap gap-4 mt-8">
              <a
                href="tel:05147259005"
                className="btn-primary flex-1 justify-center"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                تماس فوری
              </a>
              <a
                href="https://wa.me/989214970647"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary flex-1 justify-center"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.59.049-.176.296-.68.965-.939 1.162-.173.114-.34.176-.514.049-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                واتساپ
              </a>
            </div>

            <div className="flex items-center gap-4 mt-6">
              <span className="text-gray-600 text-sm">ما را در شبکه‌های اجتماعی دنبال کنید:</span>
              <a
                href="https://instagram.com/Kin__Fix"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 rounded-xl flex items-center justify-center text-white hover:scale-110 transition-transform duration-300"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
            </div>

            <div className="mt-8 glass-card overflow-hidden">
              <div className="bg-gray-200 h-64 flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <svg className="w-16 h-16 mx-auto mb-3 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <p className="text-sm">مجتمع پزشکی پارسه، قوچان</p>
                </div>
              </div>
            </div>
          </div>

          <div
            ref={formRef}
            className={`transition-all duration-700 delay-200 ${
              formVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
            }`}
          >
            <form className="glass-card p-8 space-y-6">
              <div>
                <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                  نام و نام خانوادگی
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#00a86b] focus:ring-2 focus:ring-[#00a86b]/20 transition-all outline-none"
                  placeholder="نام خود را وارد کنید"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-gray-700 font-medium mb-2">
                  شماره تماس
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#00a86b] focus:ring-2 focus:ring-[#00a86b]/20 transition-all outline-none"
                  placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                  dir="ltr"
                />
              </div>

              <div>
                <label htmlFor="service" className="block text-gray-700 font-medium mb-2">
                  نوع خدمات مورد نیاز
                </label>
                <select
                  id="service"
                  name="service"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#00a86b] focus:ring-2 focus:ring-[#00a86b]/20 transition-all outline-none bg-white"
                >
                  <option value="">انتخاب کنید</option>
                  <option value="physiotherapy">فیزیوتراپی</option>
                  <option value="corrective">حرکات اصلاحی</option>
                  <option value="rehabilitation">توانبخشی پس از جراحی</option>
                  <option value="sports">درمان آسیب‌های ورزشی</option>
                  <option value="pain">درمان کمردرد و گردن‌درد</option>
                  <option value="arthritis">درمان آرتروز</option>
                  <option value="elderly">توانبخشی سالمندان</option>
                  <option value="children">درمان کودکان</option>
                  <option value="other">سایر خدمات</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-gray-700 font-medium mb-2">
                  توضیحات (اختیاری)
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#00a86b] focus:ring-2 focus:ring-[#00a86b]/20 transition-all outline-none resize-none"
                  placeholder="توضیحات یا سوالات خود را بنویسید..."
                ></textarea>
              </div>

              <button
                type="submit"
                className="btn-primary w-full justify-center"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
                ارسال درخواست
              </button>

              <p className="text-center text-gray-500 text-sm">
                تیم ما در اسرع وقت با شما تماس خواهد گرفت
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
