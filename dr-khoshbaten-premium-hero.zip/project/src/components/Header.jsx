import { useState, useEffect } from 'react';
import logoUrl from '../assets/khoshbaten-logo.png';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '#services', label: 'خدمات کلینیکی' },
    { href: '#about', label: 'درباره ما' },
    { href: '#process', label: 'فرآیند درمان' },
    { href: '#faq', label: 'سوالات متداول' },
    { href: '#contact', label: 'تماس با ما' },
  ];

  return (
    <header
      className={`fixed top-0 right-0 left-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-white/90 backdrop-blur-lg shadow-lg py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <nav className="flex items-center justify-between">
          <a href="#" className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg shadow-[#00a86b]/25 bg-white/95 overflow-hidden ring-1 ring-emerald-200/40">
              <img src={logoUrl} alt="لوگوی دکتر خوش باطن" className="w-full h-full object-contain p-1" />
            </div>
            <div className="hidden sm:block">
              <h1 className={`text-lg font-bold transition-colors ${isScrolled ? 'text-gray-800' : 'text-white'}`}>
                کلینیک تخصصی بیومکانیک
              </h1>
              <p className={`text-xs transition-colors ${isScrolled ? 'text-gray-500' : 'text-white/80'}`}>
                دکتر خوش‌باطن
              </p>
            </div>
          </a>

          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className={`font-medium transition-all hover:text-[#00a86b] ${
                  isScrolled ? 'text-gray-700' : 'text-white'
                }`}
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-4">
            <a href="#contact" className="btn-primary">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
              رزرو نوبت
            </a>
          </div>

          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2"
            aria-label="منو"
          >
            <svg
              className={`w-6 h-6 transition-colors ${isScrolled ? 'text-gray-800' : 'text-white'}`}
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              {isMobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </nav>

        {isMobileMenuOpen && (
          <div className="lg:hidden mt-4 pb-4" style={{ animation: 'fade-in 0.3s ease-out' }}>
            <div className="glass-card p-4 space-y-3">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block py-2 px-4 text-gray-700 font-medium rounded-lg hover:bg-[#f0fdf4] transition-colors"
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#contact"
                onClick={() => setIsMobileMenuOpen(false)}
                className="btn-primary w-full justify-center mt-4"
              >
                رزرو نوبت
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
