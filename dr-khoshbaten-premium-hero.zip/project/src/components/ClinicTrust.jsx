import { useScrollReveal } from '../hooks/useScrollReveal';

const ClinicTrust = () => {
  const [titleRef, titleVisible] = useScrollReveal();
  const [contentRef, contentVisible] = useScrollReveal();
  const [statsRef, statsVisible] = useScrollReveal();

  const trustPoints = [
    {
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
        </svg>
      ),
      title: 'اعتبار و تخصص',
      description: 'بیش از ۱۵ سال سابقه درخشان در توانبخشی'
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.281-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.281.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      ),
      title: 'تیم مجرب',
      description: 'متخصصین با تجربه بالا و دلسوز'
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
        </svg>
      ),
      title: 'م Equipment پیشرفته',
      description: 'دستگاه‌های مدرن و تکنولوژی روز'
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
        </svg>
      ),
      title: 'رضایت بیماران',
      description: '۹۸ درصد رضایت مثبت بازخورد'
    }
  ];

  const certificates = [
    'مجوز رسمی وزارت بهداشت',
    'عضو سازمان نظام پزشکی',
    'گواهینامه‌های بین‌المللی',
    'استانداردهای جهانی JCI'
  ];

  return (
    <section id="trust" className="py-24 bg-gradient-to-b from-gray-900 to-gray-800 relative overflow-hidden">
      <div className="absolute inset-0 bg-pattern opacity-5"></div>
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-[#00a86b]/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 left-0 w-96 h-96 bg-[#fbbf24]/10 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div
          ref={titleRef}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block px-4 py-2 bg-[#fbbf24]/20 text-[#fcd34d] rounded-full text-sm font-semibold mb-4">
            اعتماد شما افتخار ماست
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            چرا کلینیک ما را انتخاب کنید؟
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            با تیمی با تجربه و متخصص در کنار شما هستیم تا به سلامتی کامل برسید
          </p>
        </div>

        <div
          ref={contentRef}
          className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16 transition-all duration-700 ${
            contentVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Left: Team/Clinic image */}
          <div className="relative">
            <div className="relative rounded-3xl overflow-hidden bg-gray-800">
              <img
                src="https://images.pexels.com/photos/4162492/pexels-photo-4162492.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="تیم کلینیک"
                className="w-full aspect-[4/3] object-cover opacity-80 hover:opacity-100 transition-opacity duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>

              {/* Floating badge */}
              <div className="absolute bottom-4 right-4 left-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-jade rounded-xl flex items-center justify-center">
                    <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.281-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.281.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-white font-bold mb-1">تیم تخصصی ما</h3>
                    <p className="text-gray-400 text-sm">متخصصین با تجربه و دلسوز</p>
                  </div>
                </div>
              </div>

              {/* Corner decorations */}
              <div className="absolute top-4 left-4 w-16 h-16 border-l-2 border-t-2 border-[#4ade80]/50 rounded-tl-2xl"></div>
              <div className="absolute top-4 right-4 w-16 h-16 border-r-2 border-t-2 border-[#fbbf24]/50 rounded-tr-2xl"></div>
            </div>
          </div>

          {/* Right: Trust points */}
          <div className="space-y-6">
            {trustPoints.map((point, index) => (
              <div
                key={index}
                className="group flex items-start gap-4 p-5 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl hover:bg-white/10 hover:border-[#00a86b]/30 transition-all duration-300"
              >
                <div className="w-16 h-16 flex-shrink-0 bg-gradient-jade rounded-xl flex items-center justify-center text-white group-hover:scale-110 transition-transform duration-300">
                  {point.icon}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white mb-2">{point.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{point.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Stats section */}
        <div
          ref={statsRef}
          className={`grid grid-cols-2 md:grid-cols-4 gap-6 mb-12 transition-all duration-700 ${
            statsVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {[
            { number: '۱۵+', label: 'سال تجربه' },
            { number: '۵۰۰۰+', label: 'بیمار درمان شده' },
            { number: '۹۸%', label: 'رضایت بیماران' },
            { number: '۱۲+', label: 'خدمات تخصصی' },
          ].map((stat, index) => (
            <div
              key={index}
              className="text-center p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl hover:bg-white/10 transition-all duration-300"
            >
              <div className="text-3xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#4ade80] to-[#00a86b] mb-2">
                {stat.number}
              </div>
              <div className="text-gray-400 text-sm">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Certificates */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {certificates.map((cert, index) => (
            <div
              key={index}
              className="flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-gray-400 text-sm hover:border-[#00a86b]/30 transition-colors"
            >
              <svg className="w-4 h-4 text-[#4ade80]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              {cert}
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <a
            href="#contact"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-jade text-white font-semibold rounded-xl shadow-lg shadow-[#00a86b]/30 hover:shadow-xl hover:shadow-[#00a86b]/40 transform hover:-translate-y-0.5 transition-all duration-300"
          >
            شروع مشاوره رایگان
            <svg className="w-5 h-5 rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

export default ClinicTrust;
