import { useEffect, useRef, useState } from 'react';

const ScrollTransformation = () => {
  const containerRef = useRef(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      if (!containerRef.current) return;

      const rect = containerRef.current.getBoundingClientRect();
      const windowHeight = window.innerHeight;
      const elementTop = rect.top;
      const elementHeight = rect.height;

      // Calculate progress from 0 to 1 as element scrolls through viewport
      let progress = 0;
      if (elementTop < windowHeight && elementTop > -elementHeight) {
        progress = Math.min(Math.max((windowHeight - elementTop) / (windowHeight + elementHeight), 0), 1);
      } else if (elementTop <= -elementHeight) {
        progress = 1;
      }

      setScrollProgress(progress);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Calculate transformations based on scroll progress
  const bodyTilt = -15 + (scrollProgress * 15); // Bent to straight
  const neckAngle = 20 - (scrollProgress * 20); // Forward head to neutral
  const shoulderHeight = -10 + (scrollProgress * 10); // Rounded to neutral
  const spineCurve = 8 - (scrollProgress * 8); // Curved to straight

  const badOpacity = Math.max(0, 1 - scrollProgress * 2);
  const goodOpacity = Math.max(0, scrollProgress * 2 - 1);

  return (
    <section ref={containerRef} className="py-24 bg-gradient-to-b from-gray-900 to-gray-800 relative overflow-hidden min-h-[120vh]">
      <div className="absolute inset-0 bg-pattern opacity-10"></div>
      <div className="absolute top-1/4 left-0 w-96 h-96 bg-[#00a86b]/20 rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-[#fbbf24]/20 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 bg-[#00a86b]/20 text-[#4ade80] rounded-full text-sm font-semibold mb-4">
            تصحیح فرم بدن
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            مشاهده تصحیح ناهنجاری‌ها
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            با اسکرول کنید تا تبدیل فرم بدن از حالت ناهنجار به حالت صحیح را مشاهده کنید
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
          {/* Left side - Before */}
          <div className="text-center lg:text-right">
            <div
              className="glass-card p-6 inline-block"
              style={{ opacity: badOpacity > 0.1 ? 1 : 0.3, transition: 'opacity 0.3s' }}
            >
              <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2 justify-center lg:justify-start">
                <svg className="w-6 h-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
                قبل از درمان
              </h3>
              <ul className="text-gray-400 space-y-2 text-sm">
                <li className="flex items-center gap-2 justify-center lg:justify-start">
                  <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                  سر به جلو (Forward Head)
                </li>
                <li className="flex items-center gap-2 justify-center lg:justify-start">
                  <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                  شانه‌های گرد و برجسته
                </li>
                <li className="flex items-center gap-2 justify-center lg:justify-start">
                  <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                  کایفوز بیش از حد
                </li>
                <li className="flex items-center gap-2 justify-center lg:justify-start">
                  <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                  گودی کمر (لوردوز)
                </li>
              </ul>
            </div>
          </div>

          {/* Center - Body visualization */}
          <div className="flex justify-center items-center py-8">
            <div className="relative w-48 h-80">
              {/* Background glow */}
              <div
                className="absolute inset-0 rounded-3xl blur-2xl transition-all duration-500"
                style={{
                  background: scrollProgress > 0.5
                    ? 'linear-gradient(135deg, rgba(34, 197, 94, 0.3) 0%, rgba(0, 168, 107, 0.3) 100%)'
                    : 'linear-gradient(135deg, rgba(239, 68, 68, 0.3) 0%, rgba(185, 28, 28, 0.3) 100%)'
                }}
              ></div>

              {/* Body silhouette */}
              <svg
                viewBox="0 0 200 400"
                className="w-full h-full relative z-10"
                style={{ transition: 'all 0.1s ease-out' }}
              >
                {/* Head */}
                <ellipse
                  cx="100"
                  cy="40"
                  rx="30"
                  ry="35"
                  fill="#fcd34d"
                  style={{
                    transform: `translateY(${neckAngle}px)`,
                    transformOrigin: 'center',
                    transition: 'transform 0.1s ease-out'
                  }}
                />

                {/* Neck */}
                <rect
                  x="90"
                  y="70"
                  width="20"
                  height="25"
                  rx="5"
                  fill="#a3e635"
                  style={{
                    transform: `rotate(${neckAngle * 0.3}deg)`,
                    transformOrigin: 'center bottom',
                    transition: 'transform 0.1s ease-out'
                  }}
                />

                {/* Shoulders */}
                <path
                  d={`M 40 95 Q ${60 + shoulderHeight} 90, 100 95 Q ${140 - shoulderHeight} 90, 160 95`}
                  fill="none"
                  stroke="#4ade80"
                  strokeWidth="12"
                  strokeLinecap="round"
                  style={{ transition: 'all 0.1s ease-out' }}
                />

                {/* Upper back (kyphosis curve) */}
                <path
                  d={`M 100 95 L 100 180 Q ${100 - spineCurve * 2} 200, ${100 - spineCurve} 240 L ${100 - spineCurve - 10} 280`}
                  fill="none"
                  stroke="#00a86b"
                  strokeWidth="16"
                  strokeLinecap="round"
                  style={{ transition: 'all 0.1s ease-out' }}
                />

                {/* Lower back (lordosis curve) */}
                <path
                  d={`M ${100 - spineCurve - 10} 280 Q ${130 - spineCurve} 320, ${120 - spineCurve} 360`}
                  fill="none"
                  stroke="#008f5b"
                  strokeWidth="14"
                  strokeLinecap="round"
                  style={{ transition: 'all 0.1s ease-out' }}
                />

                {/* Pelvis */}
                <ellipse
                  cx={120 - spineCurve}
                  cy="375"
                  rx="35"
                  ry="20"
                  fill="#166534"
                  style={{ transition: 'all 0.1s ease-out' }}
                />

                {/* Arms */}
                <path
                  d="M 50 100 Q 30 150, 35 220"
                  fill="none"
                  stroke="#4ade80"
                  strokeWidth="10"
                  strokeLinecap="round"
                />
                <path
                  d="M 150 100 Q 170 150, 165 220"
                  fill="none"
                  stroke="#4ade80"
                  strokeWidth="10"
                  strokeLinecap="round"
                />

                {/* Legs */}
                <path
                  d="M 95 385 L 70 450 L 65 490"
                  fill="none"
                  stroke="#008f5b"
                  strokeWidth="14"
                  strokeLinecap="round"
                />
                <path
                  d="M 125 385 L 150 450 L 155 490"
                  fill="none"
                  stroke="#008f5b"
                  strokeWidth="14"
                  strokeLinecap="round"
                />

                {/* Spine line visualization */}
                <path
                  d={`M 100 95 ${Array.from({ length: 10 }, (_, i) => {
                    const y = 95 + (i + 1) * 18;
                    const x = 100 + Math.sin(i * 0.5 + scrollProgress * 2) * (spineCurve - scrollProgress * spineCurve);
                    return `L ${x} ${y}`;
                  }).join(' ')}`}
                  fill="none"
                  stroke="#fbbf24"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeDasharray="5 5"
                  style={{ transition: 'all 0.1s ease-out' }}
                />
              </svg>

              {/* Progress indicator */}
              <div className="absolute -right-4 top-1/2 -translate-y-1/2 w-2 h-48 bg-gray-700 rounded-full overflow-hidden">
                <div
                  className="w-full bg-gradient-to-b from-[#00a86b] to-[#4ade80] transition-all duration-300"
                  style={{ height: `${scrollProgress * 100}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Right side - After */}
          <div className="text-center lg:text-left">
            <div
              className="glass-card p-6 inline-block"
              style={{ opacity: goodOpacity > 0.1 ? 1 : 0.3, transition: 'opacity 0.3s' }}
            >
              <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2 justify-center lg:justify-start">
                <svg className="w-6 h-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                بعد از درمان
              </h3>
              <ul className="text-gray-400 space-y-2 text-sm">
                <li className="flex items-center gap-2 justify-center lg:justify-start">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  سر در موقعیت خنثی
                </li>
                <li className="flex items-center gap-2 justify-center lg:justify-start">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  شانه‌های صاف و عقب
                </li>
                <li className="flex items-center gap-2 justify-center lg:justify-start">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  انحنای طبیعی ستون فقرات
                </li>
                <li className="flex items-center gap-2 justify-center lg:justify-start">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  کمر صاف و قوی
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Progress text */}
        <div className="text-center mt-12">
          <div className="inline-flex items-center gap-4 px-6 py-3 rounded-full bg-white/5 backdrop-blur-sm border border-white/10">
            <span className="text-gray-400 text-sm">میزان تصحیح:</span>
            <div className="w-48 h-2 bg-gray-700 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#00a86b] to-[#4ade80] transition-all duration-300"
                style={{ width: `${scrollProgress * 100}%` }}
              ></div>
            </div>
            <span className="text-white font-bold min-w-[3rem]">{Math.round(scrollProgress * 100)}%</span>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <a
            href="#contact"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-jade text-white font-semibold rounded-xl shadow-lg shadow-[#00a86b]/30 hover:shadow-xl hover:shadow-[#00a86b]/40 transform hover:-translate-y-0.5 transition-all duration-300"
          >
            شروع درمان اصلاحی
            <svg className="w-5 h-5 rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

export default ScrollTransformation;
