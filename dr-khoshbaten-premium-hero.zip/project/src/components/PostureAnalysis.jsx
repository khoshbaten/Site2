import { useState } from 'react';
import { useScrollReveal } from '../hooks/useScrollReveal';

const PostureAnalysis = () => {
  const [titleRef, titleVisible] = useScrollReveal();
  const [contentRef, contentVisible] = useScrollReveal();
  const [activeFeature, setActiveFeature] = useState(0);

  const features = [
    {
      icon: (
        <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
      ),
      title: 'تحلیل رایانه‌ای حرکات',
      description: 'با استفاده از هوش مصنوعی و سیستم‌های پیشرفته، حرکات و فرم بدن شما را با دقت بالا تحلیل می‌کنیم',
      details: [
        'تحلیل تصویری فرم بدن',
        'شناسایی نقاط ضعف و ناهنجاری',
        'ارزیابی تعادل و ثبات',
        'بررسی الگوی حرکتی'
      ]
    },
    {
      icon: (
        <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
        </svg>
      ),
      title: 'گزارش جامع تخصصی',
      description: 'گزارش کامل از وضعیت فعلی بدن و برنامه اصلاحی متناسب با نیازهای فردی شما',
      details: [
        'گزارش تصویری ناهنجاری‌ها',
        'تحلیل علمی داده‌های حرکتی',
        'رتبه‌بندی شدت مشکلات',
        'پیش‌بینی روند بهبود'
      ]
    },
    {
      icon: (
        <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      ),
      title: 'برنامه درمانی هوشمند',
      description: 'دریافت برنامه تمرینی اختصاصی که به طور خودکار بر اساس تحلیل طراحی می‌شود',
      details: [
        'تمرینات اصلاحی سفارشی',
        'برنامه پیشرفته روزانه',
        'پیشنهادات سبک زندگی',
        'ویرایش برنامه بر اساس پیشرفت'
      ]
    },
    {
      icon: (
        <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
        </svg>
      ),
      title: 'پیگیری هوشمند پیشرفت',
      description: 'نظارت مداوم بر بهبود شما و تنظیم خودکار برنامه درمانی در طول دوره',
      details: [
        'ارزیابی هفتگی پیشرفت',
        'نمودار روند بهبود',
        'هشدارهای هوشمند',
        'گزارش‌دهی به متخصص'
      ]
    }
  ];

  const analysisSteps = [
    {
      step: '۱',
      title: 'ثبت تصویر/ویدیو',
      description: 'در مطب یا از راه دور'
    },
    {
      step: '۲',
      title: 'تحلیل هوش مصنوعی',
      description: 'پردازش سریع و دقیق'
    },
    {
      step: '۳',
      title: 'دریافت گزارش',
      description: 'مشاوره با متخصص'
    },
    {
      step: '۴',
      title: 'شروع درمان',
      description: 'برنامه اختصاصی'
    }
  ];

  return (
    <section id="posture-analysis" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-[#dcfce7] rounded-full blur-3xl opacity-30"></div>
      <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-[#fef3c7] rounded-full blur-3xl opacity-30"></div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div
          ref={titleRef}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block px-4 py-2 bg-gradient-to-r from-[#dcfce7] to-[#bbf7d0] text-[#166534] rounded-full text-sm font-semibold mb-4">
            تحلیل هوشمند فرم بدن
          </span>
          <h2 className="section-title">
            تحلیل Posture با
            <span className="text-[#00a86b]"> هوش مصنوعی</span>
          </h2>
          <p className="section-subtitle max-w-2xl mx-auto">
            با استفاده از پیشرفته‌ترین سیستم‌های تحلیلی، فرم بدن و الگوی حرکتی شما را دقیقاً بررسی می‌کنیم
          </p>
        </div>

        {/* Main content grid */}
        <div
          ref={contentRef}
          className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center transition-all duration-700 ${
            contentVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Left: Demo visualization */}
          <div className="relative">
            <div className="glass-card p-6 overflow-hidden">
              {/* Analysis visualization */}
              <div className="relative aspect-[4/3] bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl overflow-hidden">
                {/* Grid overlay */}
                <div className="absolute inset-0 opacity-20" style={{
                  backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
                  backgroundSize: '40px 40px'
                }}></div>

                {/* Body outline with analysis points */}
                <svg viewBox="0 0 400 350" className="absolute inset-0 w-full h-full p-8">
                  {/* Body silhouette */}
                  <ellipse cx="200" cy="80" rx="35" ry="40" fill="none" stroke="#4ade80" strokeWidth="2" className="animate-pulse" />

                  {/* Analysis points */}
                  <circle cx="200" cy="40" r="5" fill="#fbbf24" className="animate-ping" style={{ animationDuration: '2s' }}>
                    <title>سر - موقعیت خنثی</title>
                  </circle>
                  <circle cx="200" cy="120" r="5" fill="#fbbf24" className="animate-ping" style={{ animationDuration: '2s', animationDelay: '0.5s' }} />
                  <circle cx="140" cy="120" r="5" fill="#ef4444" className="animate-ping" style={{ animationDuration: '2s', animationDelay: '1s' }}>
                    <title>شانه چپ - نیاز به اصلاح</title>
                  </circle>
                  <circle cx="260" cy="120" r="5" fill="#ef4444" className="animate-ping" style={{ animationDuration: '2s', animationDelay: '1.5s' }} />
                  <circle cx="200" cy="200" r="5" fill="#22c55e" className="animate-ping" style={{ animationDuration: '2s', animationDelay: '2s' }}>
                    <title>میان پشت - طبیعی</title>
                  </circle>
                  <circle cx="180" cy="280" r="5" fill="#fbbf24" className="animate-ping" style={{ animationDuration: '2s', animationDelay: '2.5s' }} />
                  <circle cx="220" cy="280" r="5" fill="#fbbf24" className="animate-ping" style={{ animationDuration: '2s', animationDelay: '3s' }} />

                  {/* Spine line */}
                  <path
                    d="M 200 120 Q 200 160, 195 200 Q 190 240, 185 280 L 180 320 M 200 120 Q 200 160, 205 200 Q 210 240, 215 280 L 220 320"
                    fill="none"
                    stroke="#4ade80"
                    strokeWidth="2"
                    strokeDasharray="4 4"
                  />

                  {/* Alignment reference lines */}
                  <line x1="200" y1="20" x2="200" y2="330" stroke="#4ade80" strokeWidth="1" strokeDasharray="8 4" opacity="0.5" />
                </svg>

                {/* Labels */}
                <div className="absolute top-4 right-4 flex items-center gap-2 bg-black/50 backdrop-blur-sm px-3 py-1.5 rounded-lg">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-white text-xs">تحلیل زنده</span>
                </div>

                {/* Stats overlay */}
                <div className="absolute bottom-4 left-4 right-4 flex gap-2">
                  <div className="flex-1 bg-black/50 backdrop-blur-sm px-3 py-2 rounded-lg text-center">
                    <div className="text-white text-lg font-bold">۵</div>
                    <div className="text-gray-400 text-xs">نقطه تحلیل</div>
                  </div>
                  <div className="flex-1 bg-black/50 backdrop-blur-sm px-3 py-2 rounded-lg text-center">
                    <div className="text-green-400 text-lg font-bold">۳</div>
                    <div className="text-gray-400 text-xs">سالم</div>
                  </div>
                  <div className="flex-1 bg-black/50 backdrop-blur-sm px-3 py-2 rounded-lg text-center">
                    <div className="text-yellow-400 text-lg font-bold">۲</div>
                    <div className="text-gray-400 text-xs">نیاز اصلاح</div>
                  </div>
                </div>
              </div>

              {/* Quick analysis steps */}
              <div className="mt-6 grid grid-cols-4 gap-2">
                {analysisSteps.map((item, index) => (
                  <div
                    key={index}
                    className={`text-center p-3 rounded-xl transition-all duration-300 ${
                      activeFeature === 0 && index === 0 ? 'bg-[#00a86b]/10' : ''
                    } ${activeFeature === 1 && index === 1 ? 'bg-[#00a86b]/10' : ''}`}
                  >
                    <div className="w-8 h-8 mx-auto mb-2 bg-gradient-jade rounded-full flex items-center justify-center text-white text-sm font-bold">
                      {item.step}
                    </div>
                    <div className="text-xs font-bold text-gray-800">{item.title}</div>
                    <div className="text-xs text-gray-500 mt-1">{item.description}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Feature cards */}
          <div className="space-y-4">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`group glass-card p-6 cursor-pointer transition-all duration-300 ${
                  activeFeature === index
                    ? 'ring-2 ring-[#00a86b] shadow-lg shadow-[#00a86b]/20'
                    : 'hover:shadow-lg'
                }`}
                onClick={() => setActiveFeature(index)}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-16 h-16 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 ${
                    activeFeature === index
                      ? 'bg-gradient-jade text-white scale-110'
                      : 'bg-[#f0fdf4] text-[#00a86b]'
                  }`}>
                    {feature.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-800 mb-2">{feature.title}</h3>
                    <p className="text-gray-600 text-sm mb-3">{feature.description}</p>
                    <div className={`grid grid-cols-2 gap-2 transition-all duration-300 ${
                      activeFeature === index ? 'opacity-100 max-h-40' : 'opacity-0 max-h-0 overflow-hidden'
                    }`}>
                      {feature.details.map((detail, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-xs text-gray-500">
                          <svg className="w-4 h-4 text-[#00a86b]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          {detail}
                        </div>
                      ))}
                    </div>
                  </div>
                  <svg
                    className={`w-5 h-5 text-gray-400 transition-transform duration-300 ${
                      activeFeature === index ? 'rotate-90' : ''
                    }`}
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <div className="inline-flex flex-col sm:flex-row gap-4">
            <a
              href="#contact"
              className="btn-gold"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
              رزرو جلسه تحلیل رایگان
            </a>
            <a
              href="https://wa.me/989214970647"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-secondary"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.59.049-.176.296-.68.965-.939 1.162-.173.114-.34.176-.514.049-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              مشاوره آنلاین
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PostureAnalysis;
