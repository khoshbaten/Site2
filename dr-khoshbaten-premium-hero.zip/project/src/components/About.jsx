import { useScrollReveal } from '../hooks/useScrollReveal';

const About = () => {
  const [contentRef, contentVisible] = useScrollReveal();
  const [imageRef, imageVisible] = useScrollReveal();

  const features = [
    { text: '۰۰تخصص و تجربه بیش از ۱۵ سال' },
    { text: 'استفاده از روش‌های علمی و مدرن' },
    { text: 'برنامه درمانی اختصاصی برای هر بیمار' },
    { text: 'تیم متخصص مجرب و دلسوز' },
    { text: 'تجهیزات پیشرفته کلینیکی' },
    { text: 'رضایت بالای ۹۸ درصد بیماران' },
  ];

  return (
    <section id="about" className="py-24 bg-gradient-to-b from-[#f0fdf4] to-white overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div
            ref={contentRef}
            className={`transition-all duration-700 ${
              contentVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'
            }`}
          >
            <span className="inline-block px-4 py-2 bg-[#dcfce7] text-[#16a34a] rounded-full text-sm font-semibold mb-4">
              درباره کلینیک
            </span>
            <h2 className="section-title mb-6">
              کلینیک حرکات اصلاحی
              <span className="block text-[#00a86b] mt-2">دکتر خوش‌باطن</span>
            </h2>

            <p className="text-gray-600 leading-relaxed mb-6">
              کلینیک حرکات اصلاحی دکتر خوش‌باطن با بیش از ۱۵ سال سابقه درخشان در زمینه
              توانبخشی و درمان ناهنجاری‌های اسکلتی عضلانی، یکی از معتبرترین مراکز
              درمانی در استان خراسان رضوی است.
            </p>

            <p className="text-gray-600 leading-relaxed mb-8">
              ما با به‌کارگیری پیشرفته‌ترین تجهیزات و روش‌های علمی، به هزاران بیمار
              کمک کرده‌ایم تا به زندگی فعال و بدون درد بازگردند. تیم متخصص ما با
              تمرکز بر نیازهای فردی هر بیمار، برنامه درمانی اختصاصی طراحی می‌کند.
            </p>

            <div className="grid grid-cols-2 gap-4 mb-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3">
                  <span className="w-2 h-2 bg-[#00a86b] rounded-full"></span>
                  <span className="text-gray-700 text-sm font-medium">{feature.text}</span>
                </div>
              ))}
            </div>

            <a href="#contact" className="btn-primary inline-flex">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
              رزرو مشاوره رایگان
            </a>
          </div>

          <div
            ref={imageRef}
            className={`relative transition-all duration-700 delay-200 ${
              imageVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
            }`}
          >
            <div className="relative">
              <div className="absolute -top-4 -right-4 w-72 h-72 bg-[#bbf7d0] rounded-full blur-3xl opacity-40"></div>
              <div className="absolute -bottom-4 -left-4 w-48 h-48 bg-[#fde68a] rounded-full blur-3xl opacity-40"></div>

              <div className="relative bg-white rounded-3xl shadow-2xl overflow-hidden">
                <img
                  src="https://images.pexels.com/photos/7578746/pexels-photo-7578746.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="کلینیک حرکات اصلاحی"
                  className="w-full h-80 object-cover"
                />
                <div className="p-6 bg-white">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 bg-gradient-jade rounded-xl flex items-center justify-center">
                      <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-800">دکتر خوش‌باطن</h3>
                      <p className="text-gray-600 text-sm">متخصص حرکات اصلاحی و توانبخشی</p>
                    </div>
                  </div>
                  <div className="flex gap-4 text-center">
                    <div className="flex-1 p-3 bg-[#f0fdf4] rounded-xl">
                      <div className="text-2xl font-bold text-[#00a86b]">۱۵+</div>
                      <div className="text-xs text-gray-600">سال تجربه</div>
                    </div>
                    <div className="flex-1 p-3 bg-[#fffbeb] rounded-xl">
                      <div className="text-2xl font-bold text-[#b45309]">۵۰۰۰+</div>
                      <div className="text-xs text-gray-600">بیمار موفق</div>
                    </div>
                    <div className="flex-1 p-3 bg-[#f0fdf4] rounded-xl">
                      <div className="text-2xl font-bold text-[#00a86b]">۹۸%</div>
                      <div className="text-xs text-gray-600">رضایت</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
