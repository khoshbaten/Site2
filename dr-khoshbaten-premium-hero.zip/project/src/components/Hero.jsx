import logoUrl from '../assets/khoshbaten-logo.png';
import doctorUrl from '../assets/doctor-portrait.jpg';
import clinicUrl from '../assets/clinic-space.jpg';

const heroBadges = ['بیومکانیک', 'آنالیز پاسچر', 'حرکات اصلاحی', 'کاهش درد'];

const metrics = [
  { label: 'زاویه سر', value: 'تحلیل دقیق', top: '16%', right: '4%' },
  { label: 'راستای شانه', value: 'تصحیح عدم تقارن', top: '36%', right: '-3%' },
  { label: 'چرخش لگن', value: 'کنترل بیومکانیکی', top: '60%', right: '2%' },
  { label: 'الگوی حرکت', value: 'بازسازی عملکرد', top: '25%', right: '72%' },
];

const Hero = () => {
  return (
    <section id="home" className="hero-cinematic relative min-h-screen overflow-hidden bg-[#031812] text-white">
      <div className="hero-mesh" aria-hidden="true" />
      <div className="hero-grid" aria-hidden="true" />
      <div className="hero-vignette" aria-hidden="true" />

      <div className="flow-field" aria-hidden="true">
        <span className="flow-line flow-line-1" />
        <span className="flow-line flow-line-2" />
        <span className="flow-line flow-line-3" />
        <span className="flow-line flow-line-4" />
      </div>

      <div className="hero-orb hero-orb-1" aria-hidden="true" />
      <div className="hero-orb hero-orb-2" aria-hidden="true" />
      <div className="hero-orb hero-orb-3" aria-hidden="true" />

      <div className="container relative z-10 mx-auto px-4 pb-20 pt-32 md:px-6 lg:pb-28 lg:pt-36">
        <div className="grid min-h-[calc(100vh-9rem)] grid-cols-1 items-center gap-10 lg:grid-cols-[0.95fr_1.05fr] xl:gap-16">
          <div className="hero-copy order-2 max-w-3xl lg:order-1">
            <div className="mb-6 inline-flex items-center gap-3 rounded-full border border-emerald-300/20 bg-white/[0.07] px-4 py-2 text-sm font-semibold text-emerald-50 shadow-[0_0_40px_rgba(0,168,107,0.18)] backdrop-blur-xl">
              <img src={logoUrl} alt="لوگوی دکتر خوش باطن" className="h-8 w-8 rounded-full object-contain ring-1 ring-white/20" />
              <span className="h-2 w-2 rounded-full bg-[#f8d46a] shadow-[0_0_18px_rgba(248,212,106,.9)]" />
              کلینیک تخصصی بیومکانیک و حرکات اصلاحی
            </div>

            <h1 className="mb-6 text-4xl font-black leading-[1.15] tracking-tight text-white md:text-6xl lg:text-7xl">
              از اصلاح پاسچر تا
              <span className="hero-title-gradient block py-2">بازگشت به عملکرد ایده‌آل</span>
            </h1>

            <p className="mb-8 max-w-2xl text-base leading-9 text-emerald-50/78 md:text-xl">
              در کلینیک تخصصی بیومکانیک و حرکات اصلاحی دکتر خوش باطن، بدن شما با نگاه علمی،
              آنالیز دقیق پاسچر و برنامه اصلاحی اختصاصی به سمت تعادل، کاهش درد و حرکت بهتر هدایت می‌شود.
            </p>

            <div className="mb-8 flex flex-wrap gap-3">
              {heroBadges.map((badge) => (
                <span key={badge} className="rounded-2xl border border-white/14 bg-white/[0.075] px-4 py-2 text-sm font-bold text-white/86 backdrop-blur-xl transition hover:-translate-y-1 hover:border-emerald-300/40 hover:bg-white/[0.12]">
                  {badge}
                </span>
              ))}
            </div>

            <div className="mb-10 flex flex-col gap-4 sm:flex-row">
              <a href="#contact" className="premium-cta premium-cta-gold justify-center text-center">
                رزرو نوبت
                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
              </a>
              <a href="#posture-analysis" className="premium-cta premium-cta-glass justify-center text-center">
                آنالیز پاسچر
              </a>
              <a href="tel:05147259005" className="premium-cta premium-cta-outline justify-center text-center">
                تماس مستقیم
              </a>
            </div>

            <div className="grid max-w-2xl grid-cols-3 gap-3 md:gap-4">
              {[
                ['ارزیابی', 'بیومکانیکی'],
                ['برنامه', 'اختصاصی'],
                ['بهبود', 'عملکرد'],
              ].map(([top, bottom], index) => (
                <div key={top} className="hero-stat-card" style={{ animationDelay: `${index * 0.12}s` }}>
                  <span className="text-2xl font-black text-white md:text-3xl">{top}</span>
                  <span className="mt-1 text-xs font-semibold text-emerald-100/70 md:text-sm">{bottom}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="hero-stage order-1 mx-auto w-full max-w-[680px] lg:order-2">
            <div className="stage-perspective">
              <div className="doctor-holo-card">
                <div className="ring-system" aria-hidden="true">
                  <span className="ring ring-1" />
                  <span className="ring ring-2" />
                  <span className="ring ring-3" />
                </div>

                <div className="doctor-frame">
                  <img src={doctorUrl} alt="دکتر مجتبی خوش باطن" className="doctor-image" />
                  <div className="doctor-fade" />
                  <div className="alignment-scan" aria-hidden="true" />
                  <div className="posture-axis axis-v" aria-hidden="true" />
                  <div className="posture-axis axis-h axis-h-1" aria-hidden="true" />
                  <div className="posture-axis axis-h axis-h-2" aria-hidden="true" />

                  <div className="doctor-name-card">
                    <span>دکتر مجتبی خوش باطن</span>
                    <small>متخصص بیومکانیک و حرکات اصلاحی</small>
                  </div>
                </div>

                {metrics.map((metric, index) => (
                  <div
                    key={metric.label}
                    className="metric-card"
                    style={{ top: metric.top, right: metric.right, animationDelay: `${index * 0.25}s` }}
                  >
                    <span>{metric.label}</span>
                    <strong>{metric.value}</strong>
                  </div>
                ))}

                <div className="clinic-preview-card">
                  <img src={clinicUrl} alt="فضای کلینیک" />
                  <div>
                    <strong>فضای تخصصی ارزیابی</strong>
                    <span>قوچان، مجتمع پزشکی پارسه</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="hero-bottom-fade" aria-hidden="true" />
      <a href="#services" className="scroll-pulse" aria-label="مشاهده بخش بعدی">
        <span>اسکرول کنید</span>
        <i />
      </a>
    </section>
  );
};

export default Hero;
