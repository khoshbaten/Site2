import { useScrollReveal } from '../hooks/useScrollReveal';

const Services = () => {
  const [titleRef, titleVisible] = useScrollReveal();
  const [servicesRef, servicesVisible] = useScrollReveal();

  const services = [
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16.5 10.5c0 1.93-1.57 3.5-3.5 3.5s-3.5-1.57-3.5-3.5S11.07 7 13 7s3.5 1.57 3.5 3.5zM13 14v4m-2 0h4m-2-11V3m-3.5 4.5L7 5m9.5 2.5L19 5M7 10.5H4m4.5 4L6 16.5M13 17v4m-3.5-4.5L7 19m9.5-6.5L19 10m-2.5 6.5L19 19" />
        </svg>
      ),
      title: 'فیزیوتراپی',
      description: 'توسط متخصصین مجرب با استفاده از دستگاه‌های پیشرفته و تکنیک‌های مدرن',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
        </svg>
      ),
      title: 'حرکات اصلاحی',
      description: 'برنامه تمرینی اختصاصی برای اصلاح ناهنجاری‌های posture و ستون فقرات',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.281-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.281.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      ),
      title: 'توانبخشی پس از جراحی',
      description: 'بازتوانی کامل پس از عمل‌های ارتوپدی و آسیب‌های جدی',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      ),
      title: 'درمان آسیب‌های ورزشی',
      description: 'توانبخشی تخصصی ورزشکاران حرفه‌ای و آماتور',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
        </svg>
      ),
      title: 'درمان کمردرد و گردن‌درد',
      description: 'روش‌های نوین درمان دردهای مزمن و حاد ناحیه کمر و گردن',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
        </svg>
      ),
      title: 'درمان آرتروز',
      description: 'مدیریت و درمان غیرجراحی آرتروز مفاصل زانو، ران و شانه',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      title: 'توانبخشی سالمندان',
      description: 'برنامه‌های ویژه بهبود تحرک و کیفیت زندگی سالمندان',
    },
    {
      icon: (
        <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      title: 'درمان کودکان',
      description: 'توانبخشی اختصاصی کودکان با محیطی دوستانه و بازی‌محور',
    },
  ];

  return (
    <section id="services" className="py-24 bg-pattern">
      <div className="container mx-auto px-4 md:px-6">
        <div
          ref={titleRef}
          className={`text-center mb-16 transition-all duration-700 ${
            titleVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <span className="inline-block px-4 py-2 bg-[#dcfce7] text-[#16a34a] rounded-full text-sm font-semibold mb-4">
            خدمات ما
          </span>
          <h2 className="section-title">خدمات تخصصی کلینیک</h2>
          <p className="section-subtitle max-w-2xl mx-auto">
            ارائه انواع خدمات حرکات اصلاحی و توانبخشی با بالاترین کیفیت و تخصص
          </p>
        </div>

        <div
          ref={servicesRef}
          className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 transition-all duration-700 ${
            servicesVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {services.map((service, index) => (
            <div
              key={index}
              className="group glass-card p-6 hover:shadow-2xl hover:shadow-[#00a86b]/10 transition-all duration-300 hover:-translate-y-2"
            >
              <div className="w-16 h-16 bg-gradient-jade rounded-xl flex items-center justify-center text-white mb-5 group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              <h3 className="text-lg font-bold text-gray-800 mb-3">{service.title}</h3>
              <p className="text-gray-600 leading-relaxed text-sm">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
