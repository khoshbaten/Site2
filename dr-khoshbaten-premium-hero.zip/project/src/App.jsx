import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import TargetAudiences from './components/TargetAudiences';
import PostureAnalysis from './components/PostureAnalysis';
import ScrollTransformation from './components/ScrollTransformation';
import About from './components/About';
import TreatmentProcess from './components/TreatmentProcess';
import Benefits from './components/Benefits';
import ClinicTrust from './components/ClinicTrust';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <Services />
        <TargetAudiences />
        <PostureAnalysis />
        <ScrollTransformation />
        <About />
        <TreatmentProcess />
        <Benefits />
        <ClinicTrust />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
